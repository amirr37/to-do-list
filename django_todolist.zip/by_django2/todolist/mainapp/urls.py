from django.urls import path
from . import views

urlpatterns = [
    path('', views.main_page, name="main_page"),
    path('add-task', views.add_task_page, name="add_task_page"),
    path('edit-task/<str:id>', views.edit_task_page, name="edit_task_page"),
    path('tasks', views.all_tasks_page, name="all_tasks_page"),
    path('categories', views.all_categories_page, name="all_categories_page"),
    path('categories/<str:category>', views.category_page, name="category-page"),
    path('tasks/<str:title>' , views.task_page , name="task-page"),
    path('detele-task/<int:id>' , views.delete_task_page , name='delete_task_page'),
    path('priority/<str:priority>', views.priority_page, name='priority_page'),
]