from django.shortcuts import render
from .models import Task
from datetime import date
from .linkedlistCode import LinkedList, Node


# Create your views here.
# sort title- duedate / edit task

def main_page(request):
    print(request.POST)
    text = ''
    sort_by = ''
    tasks_ll = None
    if request.method == 'POST':
        if request.POST['search_result'] is not None:
            text = request.POST['search_result']
            tasks = Task.objects.all().filter(title__contains=text)

        if request.POST['sort_by'] is not None:

            if request.POST['sort_by'] == 'title':
                tasks = tasks.order_by('title').values()
            elif request.POST['sort_by'] == '-title':
                tasks = tasks.order_by('-title').values()
            elif request.POST['sort_by'] == 'priority':
                tasks = tasks.order_by('priority').values()
            elif request.POST['sort_by'] == '-priority':
                tasks = tasks.order_by('-priority').values()
            elif request.POST['sort_by'] == 'created_date':
                tasks = tasks.order_by('created_date').values()
            elif request.POST['sort_by'] == '-created_date':
                tasks = tasks.order_by('-created_date').values()
            elif request.POST['sort_by'] == 'due_date':
                tasks = tasks.order_by('due_date').values()
            elif request.POST['sort_by'] == '-due_date':
                tasks = tasks.order_by('-due_Date').values()
        tasks_ll = LinkedList()
        for task in tasks:
            tasks_ll.add_last(task)

    return render(request, 'main_page_reference.html', {'text': text,
                                                        'tasks': tasks_ll})


def add_task_page(request):
    new_task = None
    if request.method == 'POST':
        new_task = Task(title=request.POST['title'],
                        steps=request.POST['steps'],
                        note=request.POST['note'],
                        category=request.POST['category'],
                        created_date=(str(date.today())),
                        due_date=request.POST['due_date'],
                        priority=request.POST['priority'])
        new_task.save()
    return render(request, 'add_task_reference.html')


def edit_task_page(request, id):
    is_edited = False
    if request.method == 'POST':
        id = request.POST['id']
        task = Task.objects.all().filter(id=id)[0]
        task.title = request.POST['title']
        task.steps = request.POST['steps']
        task.note = request.POST['note']
        task.category = request.POST['category']
        # task.created_date = request.POST['created-date']
        task.due_date = request.POST['due_date']
        task.priority = request.POST['priority']
        task.save()
        is_edited = True

    return render(request, 'edit_task_reference.html', {'task': Task.objects.all().filter(id=id)[0],
                                                        'is_edited': is_edited})


def delete_task_page(request, id):
    Task.objects.all().filter(id=id).delete()

    return render(request, 'delete_task_reference.html')


def all_tasks_page(request):
    return render(request, 'all_tasks_reference.html', {'tasks': Task.objects.all()})


def all_categories_page(request):
    return render(request, 'all_categories_reference.html',
                  {'categories': set([task.category for task in Task.objects.all()])})


def category_page(request, category):
    return render(request, 'category_reference.html', {'tasks': Task.objects.all().filter(category=category)})


def task_page(request, title):
    return render(request, 'task_reference.html')


def priority_page(request, priority):
    return render(request, 'priority_reference.html',
                  {'tasks': Task.objects.all().filter(priority=priority), 'priority': priority})
