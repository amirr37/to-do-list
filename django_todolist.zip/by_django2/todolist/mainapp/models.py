from django.db import models


# Create your models here.


class Task(models.Model):
    title = models.CharField(max_length=300)
    steps = models.CharField(max_length=700)
    note = models.TextField(max_length=3000)
    category = models.CharField(max_length=200, default=None, null=True)
    created_date = models.CharField(max_length=200)
    due_date = models.CharField(max_length=200)
    priority = models.CharField(max_length=3 , default='a')

    def __str__(self):
        return f"{self.title} ({self.due_date})"

